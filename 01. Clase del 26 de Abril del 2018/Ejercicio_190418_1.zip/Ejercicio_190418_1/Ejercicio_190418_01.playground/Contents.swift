// Ejercicio_190418_1

import UIKit

func Codificar(cadena1:String, cadena2:String) -> String{
    
    let cadenasuma = cadena1 + cadena2
    
    var nuevacadena = ""
    
    for _ in cadenasuma {
        
        nuevacadena.append("*")
        
    }
    
    return nuevacadena
    
}

let cadena1:String?

let cadena2:String?

cadena1 = "the greatest "

cadena2 = "course!"

let resultado = Codificar(cadena1: cadena1!,cadena2:cadena2!)

print("Conversión: \(resultado)")
