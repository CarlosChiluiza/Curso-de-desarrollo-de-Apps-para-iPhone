//
//  Transform.swift
//  EJERCICIO_190418
//
//  CURSO "DESARROLLO DE APPS PARA iPhone" 19/4/18.
//  Copyright © 2018 Enrique Tapiador Donaire. All rights reserved.
//

import UIKit

class Transform: UIViewController {
    
    
    @IBOutlet weak var Field1: UITextField!
    
    @IBOutlet weak var Field2: UITextField!
    
    @IBOutlet weak var ButtonTransform: UIButton!
    
    @IBOutlet weak var Resultado: UILabel!
    
    @IBAction func ButtonTransformAction(_ sender: UIButton) {
        
        let cadena1:String = Field1.text!
        let cadena2:String = Field2.text!
        
        let result = Codify(word1: cadena1, word2: cadena2)
        
        Resultado.text = result
        
        print(result)
        
    }
    
    // Función que transforma las cadenas en asteriscos
    func Codify(word1:String, word2:String)->String{
        
        let suma = word1 + word2
        
        var cadenatransformada = ""
        
        for _ in suma {
            
            cadenatransformada = cadenatransformada + "*"
            
        }
        
        return cadenatransformada
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
}
