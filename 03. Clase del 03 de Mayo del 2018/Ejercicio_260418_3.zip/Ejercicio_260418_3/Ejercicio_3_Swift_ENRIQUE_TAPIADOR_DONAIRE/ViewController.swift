//
//  ViewController.swift
//  Ejercicio_3_Swift_ENRIQUE_TAPIADOR_DONAIRE
//
//  Created by Enrique Tapiador Donaire on 18/4/16.
//  Copyright © 2016 Enrique Tapiador Donaire. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var etiquetaResultado: UILabel!
    
    // Inicialización de variables de control
    // El uso de Double nos evita más tarde ( que en el caso de un FLoat ) la notación exponencial
        var resultado:Double = 0
        var numeroActual:Double = 0
        var operacionActual:String = "="
    
    
    // Estado de la app al iniciar
    override func viewDidLoad() {
        
        super.viewDidLoad()
        etiquetaResultado.text = "\(resultado)"
    }



    // Gestión de los números de la calculadora
    @IBAction func numeros(_ sender: UIButton) {
        
        // Definir la base decimal del número en curso
            numeroActual = numeroActual * 10
        
        // Sumar a la base decimal en curso el botón pulsado, tras haber
        // convertido a un Double el texto asociado
            numeroActual = numeroActual + Double(Int(sender.titleLabel!.text!)!)
        
        // Imprimir en la pantalla de la calculadora el estado de numeroActual
            etiquetaResultado.text = "\(numeroActual)"
        
    }
    

    
    @IBAction func operacion(_ sender: UIButton) {
        
        
        // Gestión de las operaciones
            switch operacionActual{
            
            case "=":
                resultado = numeroActual
            case "+":
                resultado = resultado + numeroActual
            case "-":
                resultado = resultado - numeroActual
            case "*":
                resultado = resultado * numeroActual
            case "÷":
                resultado = resultado / numeroActual
            default:
                print("Error")
            }

        // Inicializar valores
            numeroActual = 0
        
        // Imprimir el resultado tras las operaciones
            etiquetaResultado.text = ("\(resultado)")
        
        // Gestión de la tecla "=" fuera del switch
            if (sender.titleLabel!.text == "=") { resultado = 0 }
        
        // Transformar el contenido del botón de operación en string
        operacionActual = (sender.titleLabel!.text! as String?)!

    }
    
    

    // Gestión del botón DEL de la calculadora
    @IBAction func DEL(_ sender: UIButton) {
        
        resultado = 0
        numeroActual = 0
        operacionActual = "="
        etiquetaResultado.text = ("\(resultado)")
        
    }
    
    
}

