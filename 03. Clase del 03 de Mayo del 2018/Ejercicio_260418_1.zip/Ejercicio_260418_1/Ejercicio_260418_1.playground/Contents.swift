// Ejercicio_260418_1

import UIKit

func Promedio(array:Array<Float>) -> Float {
    
    var promedio:Float?
    
    promedio = 0
    
    for number in array {
        
        promedio = promedio! + number
        
    }
    
    promedio = promedio! / Float(array.count)
    
    return promedio!
    
}

var notas = [Float]()

notas = [5.4,6.2,1.1,3.2,8.4,5.1]

let resultado = Promedio(array: notas)

print ("Promedio = \(resultado)")


