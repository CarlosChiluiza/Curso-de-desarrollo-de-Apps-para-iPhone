// Ejercicio_260418_2

import UIKit

func Invertir(cadena:String) -> String{

    var cadenainvertida = ""

    var array = [Character]()

    for caracter in cadena{

        array.append(caracter)

    }

    for caracter in stride(from: array.count-1, through: 0, by: -1) {

        cadenainvertida.append(array[caracter])

    }

    return cadenainvertida

}

let cadena = "Hola mundo!"

let resultado = Invertir(cadena: cadena)

print("Inversión: \(resultado)")



